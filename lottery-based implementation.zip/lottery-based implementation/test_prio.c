#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char *argv[])
{
    int n = 25;
    int x;

    for (int k = 0; k < n; k++)
    {
        int id = fork();
        if (id < 0)
        {
            printf("fork failed\n");
        }
        else if (id == 0)
        {
            x = 0;
            set_tickets(getpid(), k*5+10);
            for (int z = 0; z < __INT_MAX__; z += 1)
            {
                x++;
            }
            exit(0);
        }
        else
        {
            sleep(1);
            if ((k + 1) % 5 == 0)
            {
                cps();
            }
        }
    }

    for (int k = 0; k < n; k++)
    {
        wait(0);
    }

    exit(0);
}
