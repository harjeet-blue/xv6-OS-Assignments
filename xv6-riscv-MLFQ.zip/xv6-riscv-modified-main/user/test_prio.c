#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"

int main(int argc, char *argv[])
{
    int k, n, id;
    int x, z, d;

    if (argc < 2)
    {
        n = 1;
    }
    else
    {
        n = atoi(argv[1]);
    }

    if (n < 0 || n > 20)
    {
        n = 3;
    }

    if (argc < 3)
    {
        d = 1;
    }
    else
    {
        d = atoi(argv[2]);
    }

    x = 0;
    id = 0;
    for (k = 0; k < n; k++)
    {
        id = fork();
        if (id < 0)
        {
            printf("fork failed\n");
        }
        else if (id == 0)
        {
            printf("pid: %d, priority: %d, x: %d\n", getpid(), n, x);
            x = 0;
            // waste some time
            for (z = 0; z < __INT_MAX__; z += d)
            {
                // sleep(1);
                x = x + 1;
            }
        }
        else
        {
            printf("parent: %d, child: %d\n", getpid(), id);
            // wait(0);
        }
    }
        exit(0);
}