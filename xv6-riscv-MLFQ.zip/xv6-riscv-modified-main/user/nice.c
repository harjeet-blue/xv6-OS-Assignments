#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        fprintf(2, "usage: nice pid priority\n");
        exit(1);
    }
    int pid = atoi(argv[1]);
    int priority = atoi(argv[2]);
    if (pid < 0 || priority < 0 || priority > 10)
    {
        fprintf(2, "invalid pid or priority\n");
        exit(1);
    }
    if (setpriority(pid, priority) < 0)
    {
        fprintf(2, "setpriority failed\n");
        exit(1);
    }
    exit(0);
}